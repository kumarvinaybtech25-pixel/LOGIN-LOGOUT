const nodemailer = require("nodemailer");

const transporter = nodemailer.createTransport({
  service: "gmail",
  auth: {
    user: process.env.EMAIL_USER,
    pass: process.env.EMAIL_PASS
  }
});

async function sendOTP(to, otp) {
  const mailOptions = {
    from: process.env.EMAIL_USER,
    to,
    subject: "Password Reset OTP",
    text: `Your OTP for password reset is: ${otp}\n\nThis OTP will expire in 10 minutes.\n\nDo not share this OTP with anyone.`
  };
  await transporter.sendMail(mailOptions);
}

module.exports = { sendOTP };
