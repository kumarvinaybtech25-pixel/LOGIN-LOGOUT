const API_BASE = "http://localhost:3000/api/auth";

/* ================= LOGIN ================= */
async function login(e) {
  e.preventDefault();
  const email = document.getElementById("email").value;
  const password = document.getElementById("password").value;

  if (!email || !password) {
    alert("Email and password required");
    return;
  }

  try {
    const res = await fetch(`${API_BASE}/login`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ email, password })
    });

    const data = await res.json();

    if (!res.ok) {
      alert(data.message || "Login failed");
      return;
    }

    localStorage.setItem("token", data.token);
    localStorage.setItem("userEmail", email);
    window.location.href = "dashboard.html";
  } catch (err) {
    alert("Server error: " + err.message);
  }
}

/* ================= REGISTER ================= */
async function register(e) {
  e.preventDefault();
  const email = document.getElementById("email").value;
  const password = document.getElementById("password").value;
  const confirm = document.getElementById("confirmPassword")?.value;

  if (!email || !password) {
    alert("Email and password required");
    return;
  }

  if (confirm && password !== confirm) {
    alert("Passwords do not match");
    return;
  }

  try {
    const res = await fetch(`${API_BASE}/register`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ email, password })
    });

    const data = await res.json();
    
    if (!res.ok) {
      alert(data.message || "Registration failed");
      return;
    }

    alert(data.message || "Registered successfully");
    window.location.href = "login.html";
  } catch (err) {
    alert("Server error: " + err.message);
  }
}

/* ================= FORGOT PASSWORD ================= */
async function sendOTP(e) {
  e.preventDefault();
  const email = document.getElementById("email").value;

  if (!email) {
    alert("Email required");
    return;
  }

  try {
    const res = await fetch(`${API_BASE}/forgot-password`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ email })
    });

    const data = await res.json();
    alert(data.message || "OTP sent");

    localStorage.setItem("resetEmail", email);
    window.location.href = "otp.html";
  } catch (err) {
    alert("Server error: " + err.message);
  }
}

/* ================= RESET PASSWORD ================= */
async function resetPassword(e) {
  e.preventDefault();
  const otp = document.getElementById("otp").value;
  const newPassword = document.getElementById("newPassword").value;
  const confirm = document.getElementById("confirmPassword").value;

  if (!otp || !newPassword) {
    alert("OTP and password required");
    return;
  }

  if (newPassword !== confirm) {
    alert("Passwords do not match");
    return;
  }

  try {
    const res = await fetch(`${API_BASE}/reset-password`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        email: localStorage.getItem("resetEmail"),
        otp,
        newPassword
      })
    });

    const data = await res.json();
    
    if (!res.ok) {
      alert(data.message || "Password reset failed");
      return;
    }

    alert(data.message || "Password reset successfully");
    window.location.href = "login.html";
  } catch (err) {
    alert("Server error: " + err.message);
  }
}

/* ================= LOGOUT ================= */
function logout() {
  localStorage.clear();
  window.location.href = "login.html";
}
